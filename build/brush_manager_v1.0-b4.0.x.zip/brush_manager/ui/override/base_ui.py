from bpy.types import Panel,Header,UILayout,Context
from...types import UIProps,AddonData,AddonDataByMode
class BaseUI:
	def draw(A,context):B=context;D=A.layout;C=UIProps.get_data(B);E=AddonData.get_data_by_context(C);A.draw_ui(B,D,E,C)
	def draw_ui(A,context:Context,layout:UILayout,addon_data:AddonDataByMode,ui_props:UIProps):0