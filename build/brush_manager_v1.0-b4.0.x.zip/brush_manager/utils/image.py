_B='brushes'
_A=True
from os.path import realpath,relpath,abspath,join,basename,dirname,exists,isfile
import bpy
from brush_manager.paths import Paths
images_folder=str(Paths.IMAGES)
def clear_image(image):
	A=image
	if not A:return
	A.gl_free();A.buffers_free();A.user_clear()
def remove_image(image):
	A=image
	if not A:return
	bpy.data.images.remove(A,do_unlink=_A,do_id_user=_A,do_ui_user=_A)
def load_image(image_name,ext='.png',from_path=_B):
	B=image_name;A=join(images_folder,from_path,B+ext)
	if not isfile(A):print('ERROR image [%s] not found in path [%s]'%(B,A));return
	return bpy.data.images.load(A,check_existing=_A)
def load_image_from_file_dir(file,image_name,ext='.png',from_path=_B):
	A=join(images_folder,from_path,image_name+ext)
	if not isfile(A):return
	return bpy.data.images.load(A,check_existing=_A)
def load_image_from_filepath(filepath):
	A=filepath
	if not isfile(A):return
	return bpy.data.images.load(A,check_existing=_A)