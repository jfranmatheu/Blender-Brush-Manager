_D='uuid'
_C=None
_B=True
_A='dirty'
import bpy
from bpy.types import Brush as BlBrush,Texture as BlTexture
from uuid import uuid4
from brush_manager.utils.tool_settings import get_ts,get_ts_brush,get_ts_brush_texture_slot
sub_owners={}
def on_brush_update(brush:BlBrush,key:str):
	A=brush
	if A is _C:return
	print("Brush '%s' Datablock -> '%s' value was changed!"%(A.name,key));A[_A]=_B
def on_brush_texture_slot_update(brush:BlBrush,key:str):
	B=brush
	if B is _C:return
	C=B.texture_slot
	if C is _C:return
	print("BrushTextureSlot '%s' Datablock -> '%s' value was changed!"%(C.name,key));B[_A]=_B;A=C.texture
	if A and _D not in A:A[_D]=uuid4().hex;A[_A]=_B
def on_brush_texture_update(brush:BlBrush,_key:str):
	C='texture_uuid';A=brush
	if A is _C:return
	print("Brush '%s' Datablock -> texture value was changed!"%A.name);B=A.texture
	if B is _C:A[C]='';A[_A]=_B
	else:
		if _D not in B:B[_D]=uuid4().hex;B[_A]=_B
		A[C]=B[_D];A[_A]=_B
def register_prop(type,attr,notify:callable,get_data:callable):A=object();sub_owners[A]=attr;bpy.msgbus.subscribe_rna(key=(type,attr),owner=A,args=(),notify=lambda*B:notify(get_data(),sub_owners[A]),options={'PERSISTENT'})
def register():
	if sub_owners:print('[brush_manager] WARN! There are owners already registered for RNA subscription!');sub_owners.clear()
	def A():
		E='COLLECTION';D='POINTER';C=bpy.data.brushes[0]
		for(A,B)in C.rna_type.properties.items():
			if B.type in{D,E}:continue
			register_prop(bpy.types.Brush,A,on_brush_update,get_ts_brush)
		for(A,B)in C.texture_slot.rna_type.properties.items():
			if B.type in{D,E}:continue
			register_prop(bpy.types.BrushTextureSlot,A,on_brush_texture_slot_update,get_ts_brush)
		register_prop(bpy.types.BrushTextureSlot,'texture',on_brush_texture_update,get_ts_brush)
	bpy.app.timers.register(A,first_interval=1)
def unregister():
	for A in sub_owners.keys():bpy.msgbus.clear_by_owner(A)