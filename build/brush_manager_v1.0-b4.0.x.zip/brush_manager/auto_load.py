_C='unregister'
_B='register'
_A=None
import os,bpy,sys,typing,inspect,pkgutil,importlib
from pathlib import Path
__all__='init',_B,_C
blender_version=bpy.app.version
modules=_A
ordered_classes=_A
def _cleanse_modules():
	global modules;B=sys.modules
	for A in modules:
		if A in B:del sys.modules[A.__name__]
def init():
	global modules;global ordered_classes
	if modules is not _A:_cleanse_modules()
	modules=get_all_submodules(Path(__file__).parent);ordered_classes=get_ordered_classes_to_register(modules)
	try:import PIL
	except ImportError:import subprocess as B;import sys;B.call([sys.executable,'-m','pip','install','Pillow'])
	for A in modules:
		if A.__name__==__name__:continue
		if hasattr(A,'init'):A.init()
		if hasattr(A,'register_classes_factory'):C,D=bpy.utils.register_classes_factory(A.register_classes_factory());setattr(A,_B,C);setattr(A,_C,D)
def register():
	for B in ordered_classes:bpy.utils.register_class(B)
	for A in modules:
		if A.__name__==__name__:continue
		if hasattr(A,_B):A.register()
def unregister():
	for B in reversed(ordered_classes):bpy.utils.unregister_class(B)
	for A in modules:
		if A.__name__==__name__:continue
		if hasattr(A,_C):A.unregister()
def get_all_submodules(directory):A=directory;return list(iter_submodules(A,A.name))
def iter_submodules(path,package_name):
	for A in sorted(iter_submodule_names(path)):yield importlib.import_module('.'+A,package_name)
def iter_submodule_names(path,root=''):
	for(E,A,B)in pkgutil.iter_modules([str(path)]):
		if B:C=path/A;D=root+A+'.';yield from iter_submodule_names(C,D)
		else:yield root+A
def get_ordered_classes_to_register(modules):return toposort(get_register_deps_dict(modules))
def get_register_deps_dict(modules):
	A=set(iter_my_classes(modules));D={A.bl_idname:A for A in A if hasattr(A,'bl_idname')};B={}
	for C in A:B[C]=set(iter_my_register_deps(C,A,D))
	return B
def iter_my_register_deps(cls,my_classes,my_classes_by_idname):yield from iter_my_deps_from_annotations(cls,my_classes);yield from iter_my_deps_from_parent_id(cls,my_classes_by_idname)
def iter_my_deps_from_annotations(cls,my_classes):
	for B in typing.get_type_hints(cls,{},{}).values():
		A=get_dependency_from_annotation(B)
		if A is not _A:
			if A in my_classes:yield A
def get_dependency_from_annotation(value):
	B='type';A=value
	if blender_version>=(2,93):
		if isinstance(A,bpy.props._PropertyDeferred):return A.keywords.get(B)
	elif isinstance(A,tuple)and len(A)==2:
		if A[0]in(bpy.props.PointerProperty,bpy.props.CollectionProperty):return A[1][B]
def iter_my_deps_from_parent_id(cls,my_classes_by_idname):
	if bpy.types.Panel in cls.__bases__:
		A=getattr(cls,'bl_parent_id',_A)
		if A is not _A:
			B=my_classes_by_idname.get(A)
			if B is not _A:yield B
def iter_my_classes(modules):
	B=get_register_base_types()
	for A in get_classes_in_modules(modules):
		if any(A in B for A in A.__bases__):
			if not getattr(A,'is_registered',False):yield A
def get_classes_in_modules(modules):
	A=set()
	for B in modules:
		for C in iter_classes_in_module(B):A.add(C)
	return A
def iter_classes_in_module(module):
	for A in module.__dict__.values():
		if inspect.isclass(A):yield A
def get_register_base_types():return set(getattr(bpy.types,A)for A in['Panel','Operator','PropertyGroup','AddonPreferences','Header','Menu','UIList'])
def toposort(deps_dict):
	A=deps_dict;C=[];D=set()
	while len(A)>0:
		E=[]
		for(B,F)in A.items():
			if len(F)==0:C.append(B);D.add(B)
			else:E.append(B)
		A={B:A[B]-D for B in E}
	return C