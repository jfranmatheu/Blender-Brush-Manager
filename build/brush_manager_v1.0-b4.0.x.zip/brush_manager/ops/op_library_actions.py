_F='SKIP_SAVE'
_E='FINISHED'
_D='HIDDEN'
_C='RUNNING_MODAL'
_B=True
_A=None
import bpy
from bpy.types import Event,Context
from bpy.props import StringProperty,BoolProperty
from os.path import basename
from pathlib import Path
from time import time,sleep
import json,subprocess
from collections import deque
from typing import Type
from..paths import Paths
from..types import UIProps,AddonDataByMode,BrushItem,TextureItem,Item
from brush_manager.addon_utils import Reg
from brush_manager.globals import GLOBALS
@Reg.Ops.setup
class ImportLibrary(Reg.Ops.Import.BLEND):
	bl_idname='brushmanager.import_library';bl_label='Import a .blend Library';create_category:BoolProperty(default=_B,name='Setup Category',description='Create a category from',options={_D});custom_uuid:StringProperty(default='');exclude_defaults:BoolProperty(default=_B,options={_D,_F});use_modal:BoolProperty(default=_B,options={_D,_F})
	def action(A,context:Context,ui_props:UIProps,addon_data:AddonDataByMode)->_A:
		I=addon_data;F=ui_props;E=context;D='CANCELLED';print('[brush_manager] ImportLibrary:',A.filepath)
		if A.filepath=='':raise ValueError('filepath must not be empty');return{D}
		J=Path(A.filepath)
		if not J.is_file()or not J.exists():raise ValueError('Invalid file-path: %s'%A.filepath);return{D}
		GLOBALS.is_importing_a_library=_B;B:Path=Paths.Scripts._SCRIPTS(f"export_{J.stem}.json",as_path=_B)
		if B.exists():B.unlink(missing_ok=_B)
		print('Start Subprocess');A.process=subprocess.Popen([bpy.app.binary_path,A.filepath,'--background','--python',Paths.Scripts.EXPORT(),'-',str(B),F.ui_context_mode,str(int(A.exclude_defaults))],stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT,shell=False);K=time()+60
		while 1:
			if B.exists():break
			if time()>K:A.end();raise TimeoutError('ImportLibrary: Timeout expired for checking json existence')
		sleep(.1);K=time()+60;C=_A
		while C is _A:
			with B.open('r')as Q:
				L=Q.read()
				if not L:print('\t> No raw data in export.json');sleep(.1);return
				C:dict[str,dict]=json.loads(L)
			if time()>K:raise TimeoutError('ImportLibrary: Timeout expired for reading json')
		if C is _A:print('\t> Invalid data in export.json');A.end();return{D}
		B.unlink();A.brushes=deque(C['brushes']);A.textures=deque(C['textures']);A.brushes_count=G=len(A.brushes);A.textures_count=H=len(A.textures);print(f"export.json: brushes_count {G} - textures_count {H}")
		if G==0 and H==0:print('WARN: No data in export.json');A.end();return{D}
		M=_A;N=_A;F=UIProps.get_data(E);O=Path(A.filepath).stem.title()
		if H!=0:print('Create Texture Category');F.ui_context_item='TEXTURE';N=I.new_texture_cat(O,A.custom_uuid)
		if G!=0:print('Create Brush Category');F.ui_context_item='BRUSH';M=I.new_brush_cat(O,A.custom_uuid)
		R=M.items.add if G!=0 else _A;S=N.items.add if H!=0 else _A;P:dict[str,object]={}
		def T(item_data:dict):A=item_data;B=P.get(A.pop('texture_uuid',''),_A);R(texture=B,**A)
		def U(item_data:dict):A=item_data;P[A['uuid']]=S(**A)
		A.add_brush_to_data=T;A.add_texture_to_data=U;A.refresh_timer=time()+.2;A.addon_data=I
		if A.use_modal:
			if not E.window_manager.modal_handler_add(A):print('ERROR: Window Manager was unable to add a modal handler');A.end();return{D}
			A._timer=E.window_manager.event_timer_add(1e-06,window=E.window);A.tag_redraw();return{_C}
		while 1:
			if _E in A.modal(_A,_A):break
		A.end();return{_E}
	def end(A):GLOBALS.is_importing_a_library=False
	def modal(A,context:Context,event:Event):
		C=event;B=context
		if C is not _A and C.type!='TIMER':return{'PASS_THROUGH'}
		if B is not _A:
			if time()>A.refresh_timer:A.refresh_timer=time()+.2;A.tag_redraw()
		if A.textures_count!=0:A.textures_count-=1;A.add_texture_to_data(A.textures.popleft());return{_C}
		if A.brushes_count!=0:A.brushes_count-=1;A.add_brush_to_data(A.brushes.popleft());return{_C}
		if A.brushes_count==0 and A.textures_count==0:
			if B is not _A:B.window_manager.event_timer_remove(A._timer);del A._timer
			A.end();A.addon_data.save();return{_E}
		return{_C}