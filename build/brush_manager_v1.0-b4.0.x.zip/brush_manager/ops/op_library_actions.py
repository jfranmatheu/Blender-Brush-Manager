_F='SKIP_SAVE'
_E='FINISHED'
_D='HIDDEN'
_C='RUNNING_MODAL'
_B=True
_A=None
import bpy
from bpy.types import Event,Context
from bpy.props import StringProperty,BoolProperty
from os.path import basename
from pathlib import Path
from time import time,sleep
import json,subprocess
from collections import deque
from typing import Type
from..paths import Paths
from..types import UIProps,AddonDataByMode,BrushItem,TextureItem,Item
from brush_manager.addon_utils import Reg
from brush_manager.globals import GLOBALS
@Reg.Ops.setup
class ImportLibrary(Reg.Ops.Import.BLEND):
	bl_idname='brushmanager.import_library';bl_label='Import a .blend Library';create_category:BoolProperty(default=_B,name='Setup Category',description='Create a category from',options={_D});custom_uuid:StringProperty(default='');exclude_defaults:BoolProperty(default=_B,options={_D,_F});use_modal:BoolProperty(default=_B,options={_D,_F})
	def action(A,context:Context,ui_props:UIProps,addon_data:AddonDataByMode)->_A:
		L='WARNING';G=addon_data;F=ui_props;E=context;C='CANCELLED';print('[brush_manager] ImportLibrary:',A.filepath)
		if A.filepath=='':A.report({L},'[brush_manager] ImportLibrary: filepath is empty');return{C}
		J=Path(A.filepath)
		if not J.is_file()or not J.exists():A.report({L},'[brush_manager] ImportLibrary: Invalid file-path: %s'%A.filepath);return{C}
		if G.get_brush_cat(A.custom_uuid)is not _A:A.report({L},'[brush_manager] ImportLibrary: a custom cat already exist with UUID: %s'%A.custom_uuid);return{C}
		GLOBALS.is_importing_a_library=_B;B:Path=Paths.Scripts._SCRIPTS(f"export_{J.stem}.json",as_path=_B)
		if B.exists():B.unlink(missing_ok=_B)
		print('[brush_manager] ImportLibrary: Start Subprocess');A.process=subprocess.Popen([bpy.app.binary_path,A.filepath,'--background','--python',Paths.Scripts.EXPORT(),'-',str(B),F.ui_context_mode,str(int(A.exclude_defaults))],stdout=_A,stderr=_A,shell=False);K=time()+60
		while 1:
			if A.process.poll()is not _A:A.end();raise TimeoutError('[brush_manager] ImportLibrary: Subprocess failed!')
			if B.exists():break
			if time()>K:A.end();raise TimeoutError('[brush_manager] ImportLibrary: Timeout expired for checking json existence')
		sleep(.1);K=time()+30;D=_A
		while D is _A:
			with B.open('r')as R:
				M=R.read()
				if not M:print('\t> No raw data in export.json');sleep(.1);break
				D:dict[str,dict]=json.loads(M)
			if time()>K:raise TimeoutError('[brush_manager] ImportLibrary: Timeout expired for reading json')
		if D is _A:print('\t> Invalid data in export.json');A.end();return{C}
		B.unlink();A.brushes=deque(D['brushes']);A.textures=deque(D['textures']);A.brushes_count=H=len(A.brushes);A.textures_count=I=len(A.textures);print(f"[brush_manager] ImportLibrary: export.json -> brushes_count {H}; textures_count {I}")
		if H==0 and I==0:print('WARN: [brush_manager] ImportLibrary: No data in export.json');A.end();return{C}
		N=_A;O=_A;F=UIProps.get_data(E);P=Path(A.filepath).stem.title()
		if I!=0:print('[brush_manager] ImportLibrary: Create Texture Category');F.ui_context_item='TEXTURE';O=G.new_texture_cat(P,A.custom_uuid)
		if H!=0:print('[brush_manager] ImportLibrary: Create Brush Category');F.ui_context_item='BRUSH';N=G.new_brush_cat(P,A.custom_uuid)
		S=N.items.add if H!=0 else _A;T=O.items.add if I!=0 else _A;Q:dict[str,object]={}
		def U(item_data:dict):A=item_data;B=Q.get(A.pop('texture_uuid',''),_A);S(texture=B,**A)
		def V(item_data:dict):A=item_data;Q[A['uuid']]=T(**A)
		A.add_brush_to_data=U;A.add_texture_to_data=V;A.refresh_timer=time()+.2;A.addon_data=G
		if A.use_modal:
			if not E.window_manager.modal_handler_add(A):print('ERROR: [brush_manager] ImportLibrary: Window Manager was unable to add a modal handler');A.end();return{C}
			A._timer=E.window_manager.event_timer_add(1e-06,window=E.window);A.tag_redraw();return{_C}
		while 1:
			if _E in A.modal(_A,_A):break
		A.end();return{_E}
	def end(A):GLOBALS.is_importing_a_library=False
	def modal(A,context:Context,event:Event):
		C=event;B=context
		if C is not _A and C.type!='TIMER':return{'PASS_THROUGH'}
		if B is not _A:
			if time()>A.refresh_timer:A.refresh_timer=time()+.2;A.tag_redraw()
		if A.textures_count!=0:A.textures_count-=1;A.add_texture_to_data(A.textures.popleft());return{_C}
		if A.brushes_count!=0:A.brushes_count-=1;A.add_brush_to_data(A.brushes.popleft());return{_C}
		if A.brushes_count==0 and A.textures_count==0:
			if B is not _A:B.window_manager.event_timer_remove(A._timer);del A._timer
			A.end();A.addon_data.save();return{_E}
		return{_C}