_C='.blend'
_B='brush_manager'
_A=True
import bpy
from brush_manager.paths import Paths
write_lib=bpy.data.libraries.write
checkfile=Paths.Scripts.CHECK__WRITE_LIBS(as_path=_A)
checkfile.touch(exist_ok=_A)
for texture in bpy.data.textures:
	if _B not in texture:continue
	uuid=texture['uuid'];texture_libpath=Paths.Data.TEXTURE(uuid+_C);texture.name=uuid;write_lib(texture_libpath,{texture},fake_user=_A,compress=_A)
for brush in bpy.data.brushes:
	if _B not in brush:continue
	uuid=brush['uuid'];brush.name=uuid;brush.texture=None;write_lib(Paths.Data.BRUSH(uuid+_C),{brush},fake_user=_A,compress=_A);write_lib(Paths.Data.BRUSH(uuid+'.default.blend'),{brush},fake_user=_A,compress=_A)
checkfile.unlink()