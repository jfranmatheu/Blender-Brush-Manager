_C='.blend'
_B='brush_manager'
_A=True
import bpy
from bpy.types import ImageTexture
from brush_manager.paths import Paths
from os.path import exists
bpy.ops.file.make_paths_absolute()
bpy.ops.file.pack_all()
write_lib=bpy.data.libraries.write
checkfile=Paths.Scripts.CHECK__WRITE_LIBS(as_path=_A)
checkfile.touch(exist_ok=_A)
for brush in bpy.data.brushes:
	if _B not in brush:continue
	uuid=brush['uuid'];brush.name=uuid;brush.texture=None;write_lib(Paths.Data.BRUSH(uuid+_C),{brush},fake_user=_A,compress=_A);write_lib(Paths.Data.BRUSH(uuid+'.default.blend'),{brush},fake_user=_A,compress=_A)
for texture in bpy.data.textures:
	if _B not in texture:continue
	if texture.type!='IMAGE':continue
	if not isinstance(texture,ImageTexture):continue
	if not texture.image:continue
	image=texture.image;uuid=texture['uuid'];texture_libpath=Paths.Data.TEXTURE(uuid+_C);texture.name=uuid;write_lib(texture_libpath,{texture,image},fake_user=_A,compress=_A)
checkfile.unlink()