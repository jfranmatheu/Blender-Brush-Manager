bl_info={'name':'Brush Manager','author':'J. Fran Matheu (@jfranmatheu)','description':'','blender':(3,6,2),'version':(1,0,1),'location':'Addon Preferences','category':'General'}
blender_version_str=str(bl_info['blender'])[1:-1].replace(', ','.')
addon_version_str=str(bl_info['version'])[1:-1].replace(', ','.')
tag_version=f"v{addon_version_str[:-2]}-b{blender_version_str[:-2]}.x"
if __package__!='brush_manager':import sys;print("[BrushManager] Please, rename the addon folder as 'brush_manager'");sys.exit(0)
import bpy
if bpy.app.background:
	def register():0
	def unregister():0
else:
	from.import auto_load;auto_load.init()
	def register():auto_load.register()
	def unregister():auto_load.unregister()