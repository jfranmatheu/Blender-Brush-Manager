_C='SCULPT'
_B='BRUSH'
_A=None
from bpy.types import Context
from .paths import Paths
ui_context_mode:str=_C
ui_context_item:str=_B
_is_importing_a_library:bool=False
class _GLOBALS:
	@property
	def is_importing_a_library(self)->bool:global _is_importing_a_library;return _is_importing_a_library or Paths.Scripts.CHECK__WRITE_LIBS(as_path=True).exists()
	@is_importing_a_library.setter
	def is_importing_a_library(self,value:bool)->_A:global _is_importing_a_library;_is_importing_a_library=value
	@property
	def ui_context_mode(self)->str:global ui_context_mode;return ui_context_mode
	@ui_context_mode.setter
	def ui_context_mode(self,ctx_mode:str)->_A:global ui_context_mode;ui_context_mode=ctx_mode
	@property
	def ui_context_item(self)->str:global ui_context_item;return ui_context_item
	@ui_context_item.setter
	def ui_context_item(self,item_type:str)->_A:global ui_context_item;ui_context_item=item_type
	@property
	def is_context_brush_item(self)->bool:global ui_context_item;return ui_context_item==_B
	@property
	def is_context_texture_item(self)->bool:global ui_context_item;return ui_context_item=='TEXTURE'
GLOBALS=_GLOBALS()
class CM_UIContext:
	def __init__(A,context:Context|_A=_A,mode:str=_C,item_type:str=_B)->_A:
		B=context
		if B:from .types import UIProps as C;A.ui_props=C.get_data(B);A.prev_mode=A.ui_props.ui_context_mode;A.prev_item_type=A.ui_props.ui_context_item
		else:A.ui_props=_A;A.prev_mode=GLOBALS.ui_context_mode;A.prev_item_type=GLOBALS.ui_context_item
		A.mode=mode;A.item_type=item_type
	def __enter__(A):
		if A.ui_props:A.ui_props.ui_context_mode=A.mode;A.ui_props.ui_context_item=A.item_type
		else:GLOBALS.ui_context_mode=A.mode;GLOBALS.ui_context_item=A.item_type
	def __exit__(A,*B):
		if A.ui_props:A.ui_props.ui_context_mode=A.prev_mode;A.ui_props.ui_context_item=A.prev_item_type
		else:GLOBALS.ui_context_mode=A.prev_mode;GLOBALS.ui_context_item=A.prev_item_type