_A=None
import bpy
from bpy.types import Brush as BlBrush,Texture as BlTexture,ToolSettings
def get_ts(context:bpy.types.Context)->ToolSettings|_A:
	B=context;A=B.mode
	if A=='PAINT_GPENCIL':A='GPENCIL_PAINT'
	A=A.lower();return getattr(B.tool_settings,A,_A)
def get_ts_brush()->BlBrush|_A:
	if(A:=get_ts(bpy.context)):return A.brush
def get_ts_brush_texture_slot()->bpy.types.BrushTextureSlot|_A:
	if(A:=get_ts_brush()):return A.texture_slot
	return _A
def set_ts_brush(context:bpy.types.Context,brush:BlBrush)->_A:
	if(A:=get_ts(context)):A.brush=brush
def set_ts_texture(context:bpy.types.Context,texture:BlTexture)->_A:
	if(A:=get_ts(context)):A.brush.texture_slot.texture=texture