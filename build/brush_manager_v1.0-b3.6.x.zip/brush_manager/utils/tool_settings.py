_A=None
import bpy
from bpy.types import Brush as BlBrush,Texture as BlTexture,ToolSettings
def get_ts(context:bpy.types.Context|_A=_A)->ToolSettings|_A:
	B=context
	if B is _A:B=bpy.context
	A=B.mode
	if A=='PAINT_GPENCIL':A='GPENCIL_PAINT'
	A=A.lower();return getattr(B.tool_settings,A,_A)
def get_ts_brush(context:bpy.types.Context|_A=_A)->BlBrush|_A:
	if(A:=get_ts(context)):return A.brush
def get_ts_brush_texture_slot(context:bpy.types.Context|_A=_A)->bpy.types.BrushTextureSlot|_A:
	if(A:=get_ts_brush(context)):return A.texture_slot
	return _A
def set_ts_brush(context:bpy.types.Context|_A=_A,brush:BlBrush=_A)->_A:
	if(A:=get_ts(context)):A.brush=brush
def set_ts_texture(context:bpy.types.Context|_A=_A,texture:BlTexture=_A)->_A:
	if(A:=get_ts(context)):A.brush.texture_slot.texture=texture