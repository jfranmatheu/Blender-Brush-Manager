'Sorted Dict\n==============\n\n:doc:`Sorted Containers<index>` is an Apache2 licensed Python sorted\ncollections library, written in pure-Python, and fast as C-extensions. The\n:doc:`introduction<introduction>` is the best way to get started.\n\nSorted dict implementations:\n\n.. currentmodule:: sortedcontainers\n\n* :class:`SortedDict`\n* :class:`SortedKeysView`\n* :class:`SortedItemsView`\n* :class:`SortedValuesView`\n\n'
_B='values'
_A=None
import sys,warnings
from itertools import chain
from .sortedlist import SortedList,recursive_repr
from .sortedset import SortedSet
try:from collections.abc import ItemsView,KeysView,Mapping,ValuesView,Sequence
except ImportError:from collections import ItemsView,KeysView,Mapping,ValuesView,Sequence
class SortedDict(dict):
	'Sorted dict is a sorted mutable mapping.\n\n    Sorted dict keys are maintained in sorted order. The design of sorted dict\n    is simple: sorted dict inherits from dict to store items and maintains a\n    sorted list of keys.\n\n    Sorted dict keys must be hashable and comparable. The hash and total\n    ordering of keys must not change while they are stored in the sorted dict.\n\n    Mutable mapping methods:\n\n    * :func:`SortedDict.__getitem__` (inherited from dict)\n    * :func:`SortedDict.__setitem__`\n    * :func:`SortedDict.__delitem__`\n    * :func:`SortedDict.__iter__`\n    * :func:`SortedDict.__len__` (inherited from dict)\n\n    Methods for adding items:\n\n    * :func:`SortedDict.setdefault`\n    * :func:`SortedDict.update`\n\n    Methods for removing items:\n\n    * :func:`SortedDict.clear`\n    * :func:`SortedDict.pop`\n    * :func:`SortedDict.popitem`\n\n    Methods for looking up items:\n\n    * :func:`SortedDict.__contains__` (inherited from dict)\n    * :func:`SortedDict.get` (inherited from dict)\n    * :func:`SortedDict.peekitem`\n\n    Methods for views:\n\n    * :func:`SortedDict.keys`\n    * :func:`SortedDict.items`\n    * :func:`SortedDict.values`\n\n    Methods for miscellany:\n\n    * :func:`SortedDict.copy`\n    * :func:`SortedDict.fromkeys`\n    * :func:`SortedDict.__reversed__`\n    * :func:`SortedDict.__eq__` (inherited from dict)\n    * :func:`SortedDict.__ne__` (inherited from dict)\n    * :func:`SortedDict.__repr__`\n    * :func:`SortedDict._check`\n\n    Sorted list methods available (applies to keys):\n\n    * :func:`SortedList.bisect_left`\n    * :func:`SortedList.bisect_right`\n    * :func:`SortedList.count`\n    * :func:`SortedList.index`\n    * :func:`SortedList.irange`\n    * :func:`SortedList.islice`\n    * :func:`SortedList._reset`\n\n    Additional sorted list methods available, if key-function used:\n\n    * :func:`SortedKeyList.bisect_key_left`\n    * :func:`SortedKeyList.bisect_key_right`\n    * :func:`SortedKeyList.irange_key`\n\n    Sorted dicts may only be compared for equality and inequality.\n\n    '
	def __init__(A,*C,**E):
		"Initialize sorted dict instance.\n\n        Optional key-function argument defines a callable that, like the `key`\n        argument to the built-in `sorted` function, extracts a comparison key\n        from each dictionary key. If no function is specified, the default\n        compares the dictionary keys directly. The key-function argument must\n        be provided as a positional argument and must come before all other\n        arguments.\n\n        Optional iterable argument provides an initial sequence of pairs to\n        initialize the sorted dict. Each pair in the sequence defines the key\n        and corresponding value. If a key is seen more than once, the last\n        value associated with it is stored in the new sorted dict.\n\n        Optional mapping argument provides an initial mapping of items to\n        initialize the sorted dict.\n\n        If keyword arguments are given, the keywords themselves, with their\n        associated values, are added as items to the dictionary. If a key is\n        specified both in the positional argument and as a keyword argument,\n        the value associated with the keyword is stored in the\n        sorted dict.\n\n        Sorted dict keys must be hashable, per the requirement for Python's\n        dictionaries. Keys (or the result of the key-function) must also be\n        comparable, per the requirement for sorted lists.\n\n        >>> d = {'alpha': 1, 'beta': 2}\n        >>> SortedDict([('alpha', 1), ('beta', 2)]) == d\n        True\n        >>> SortedDict({'alpha': 1, 'beta': 2}) == d\n        True\n        >>> SortedDict(alpha=1, beta=2) == d\n        True\n\n        "
		if C and(C[0]is _A or callable(C[0])):D=A._key=C[0];C=C[1:]
		else:D=A._key=_A
		A._list=SortedList(key=D);B=A._list;A._list_add=B.add;A._list_clear=B.clear;A._list_iter=B.__iter__;A._list_reversed=B.__reversed__;A._list_pop=B.pop;A._list_remove=B.remove;A._list_update=B.update;A.bisect_left=B.bisect_left;A.bisect=B.bisect_right;A.bisect_right=B.bisect_right;A.index=B.index;A.irange=B.irange;A.islice=B.islice;A._reset=B._reset
		if D is not _A:A.bisect_key_left=B.bisect_key_left;A.bisect_key_right=B.bisect_key_right;A.bisect_key=B.bisect_key;A.irange_key=B.irange_key
		A._update(*(C),**E)
	@property
	def key(self):'Function used to extract comparison key from keys.\n\n        Sorted dict compares keys directly when the key function is none.\n\n        ';return self._key
	@property
	def iloc(self):
		'Cached reference of sorted keys view.\n\n        Deprecated in version 2 of Sorted Containers. Use\n        :func:`SortedDict.keys` instead.\n\n        ';A=self
		try:return A._iloc
		except AttributeError:warnings.warn('sorted_dict.iloc is deprecated. Use SortedDict.keys() instead.',DeprecationWarning,stacklevel=2);B=A._iloc=SortedKeysView(A);return B
	def clear(A):'Remove all items from sorted dict.\n\n        Runtime complexity: `O(n)`\n\n        ';dict.clear(A);A._list_clear()
	def __delitem__(A,key):"Remove item from sorted dict identified by `key`.\n\n        ``sd.__delitem__(key)`` <==> ``del sd[key]``\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n        >>> del sd['b']\n        >>> sd\n        SortedDict({'a': 1, 'c': 3})\n        >>> del sd['z']\n        Traceback (most recent call last):\n          ...\n        KeyError: 'z'\n\n        :param key: `key` for item lookup\n        :raises KeyError: if key not found\n\n        ";dict.__delitem__(A,key);A._list_remove(key)
	def __iter__(A):'Return an iterator over the keys of the sorted dict.\n\n        ``sd.__iter__()`` <==> ``iter(sd)``\n\n        Iterating the sorted dict while adding or deleting items may raise a\n        :exc:`RuntimeError` or fail to iterate over all keys.\n\n        ';return A._list_iter()
	def __reversed__(A):'Return a reverse iterator over the keys of the sorted dict.\n\n        ``sd.__reversed__()`` <==> ``reversed(sd)``\n\n        Iterating the sorted dict while adding or deleting items may raise a\n        :exc:`RuntimeError` or fail to iterate over all keys.\n\n        ';return A._list_reversed()
	def __setitem__(A,key,value):
		"Store item in sorted dict with `key` and corresponding `value`.\n\n        ``sd.__setitem__(key, value)`` <==> ``sd[key] = value``\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict()\n        >>> sd['c'] = 3\n        >>> sd['a'] = 1\n        >>> sd['b'] = 2\n        >>> sd\n        SortedDict({'a': 1, 'b': 2, 'c': 3})\n\n        :param key: key for item\n        :param value: value for item\n\n        ";B=key
		if B not in A:A._list_add(B)
		dict.__setitem__(A,B,value)
	_setitem=__setitem__
	def __or__(A,other):
		B=other
		if not isinstance(B,Mapping):return NotImplemented
		C=chain(A.items(),B.items());return A.__class__(A._key,C)
	def __ror__(A,other):
		B=other
		if not isinstance(B,Mapping):return NotImplemented
		C=chain(B.items(),A.items());return A.__class__(A._key,C)
	def __ior__(A,other):A._update(other);return A
	def copy(A):'Return a shallow copy of the sorted dict.\n\n        Runtime complexity: `O(n)`\n\n        :return: new sorted dict\n\n        ';return A.__class__(A._key,A.items())
	__copy__=copy
	@classmethod
	def fromkeys(A,iterable,value=_A):'Return a new sorted dict initailized from `iterable` and `value`.\n\n        Items in the sorted dict have keys from `iterable` and values equal to\n        `value`.\n\n        Runtime complexity: `O(n*log(n))`\n\n        :return: new sorted dict\n\n        ';return A(((A,value)for A in iterable))
	def keys(A):"Return new sorted keys view of the sorted dict's keys.\n\n        See :class:`SortedKeysView` for details.\n\n        :return: new sorted keys view\n\n        ";return SortedKeysView(A)
	def items(A):"Return new sorted items view of the sorted dict's items.\n\n        See :class:`SortedItemsView` for details.\n\n        :return: new sorted items view\n\n        ";return SortedItemsView(A)
	def values(A):"Return new sorted values view of the sorted dict's values.\n\n        Note that the values view is sorted by key.\n\n        See :class:`SortedValuesView` for details.\n\n        :return: new sorted values view\n\n        ";return SortedValuesView(A)
	if sys.hexversion<50331648:
		def __make_raise_attributeerror(B,alternate):
			C='SortedDict.{original}() is not implemented. Use SortedDict.{alternate}() instead.'.format(original=B,alternate=alternate)
			def A(self):raise AttributeError(C)
			A.__name__=B;A.__doc__=C;return property(A)
		iteritems=__make_raise_attributeerror('iteritems','items');iterkeys=__make_raise_attributeerror('iterkeys','keys');itervalues=__make_raise_attributeerror('itervalues',_B);viewitems=__make_raise_attributeerror('viewitems','items');viewkeys=__make_raise_attributeerror('viewkeys','keys');viewvalues=__make_raise_attributeerror('viewvalues',_B)
	class _NotGiven:
		def __repr__(A):return'<not-given>'
	__not_given=_NotGiven()
	def pop(A,key,default=__not_given):
		"Remove and return value for item identified by `key`.\n\n        If the `key` is not found then return `default` if given. If `default`\n        is not given then raise :exc:`KeyError`.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n        >>> sd.pop('c')\n        3\n        >>> sd.pop('z', 26)\n        26\n        >>> sd.pop('y')\n        Traceback (most recent call last):\n          ...\n        KeyError: 'y'\n\n        :param key: `key` for item\n        :param default: `default` value if key not found (optional)\n        :return: value for item\n        :raises KeyError: if `key` not found and `default` not given\n\n        ";C=default;B=key
		if B in A:A._list_remove(B);return dict.pop(A,B)
		else:
			if C is A.__not_given:raise KeyError(B)
			return C
	def popitem(A,index=-1):
		"Remove and return ``(key, value)`` pair at `index` from sorted dict.\n\n        Optional argument `index` defaults to -1, the last item in the sorted\n        dict. Specify ``index=0`` for the first item in the sorted dict.\n\n        If the sorted dict is empty, raises :exc:`KeyError`.\n\n        If the `index` is out of range, raises :exc:`IndexError`.\n\n        Runtime complexity: `O(log(n))`\n\n        >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n        >>> sd.popitem()\n        ('c', 3)\n        >>> sd.popitem(0)\n        ('a', 1)\n        >>> sd.popitem(100)\n        Traceback (most recent call last):\n          ...\n        IndexError: list index out of range\n\n        :param int index: `index` of item (default -1)\n        :return: key and value pair\n        :raises KeyError: if sorted dict is empty\n        :raises IndexError: if `index` out of range\n\n        "
		if not A:raise KeyError('popitem(): dictionary is empty')
		B=A._list_pop(index);C=dict.pop(A,B);return B,C
	def peekitem(A,index=-1):"Return ``(key, value)`` pair at `index` in sorted dict.\n\n        Optional argument `index` defaults to -1, the last item in the sorted\n        dict. Specify ``index=0`` for the first item in the sorted dict.\n\n        Unlike :func:`SortedDict.popitem`, the sorted dict is not modified.\n\n        If the `index` is out of range, raises :exc:`IndexError`.\n\n        Runtime complexity: `O(log(n))`\n\n        >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n        >>> sd.peekitem()\n        ('c', 3)\n        >>> sd.peekitem(0)\n        ('a', 1)\n        >>> sd.peekitem(100)\n        Traceback (most recent call last):\n          ...\n        IndexError: list index out of range\n\n        :param int index: index of item (default -1)\n        :return: key and value pair\n        :raises IndexError: if `index` out of range\n\n        ";B=A._list[index];return B,A[B]
	def setdefault(A,key,default=_A):
		"Return value for item identified by `key` in sorted dict.\n\n        If `key` is in the sorted dict then return its value. If `key` is not\n        in the sorted dict then insert `key` with value `default` and return\n        `default`.\n\n        Optional argument `default` defaults to none.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict()\n        >>> sd.setdefault('a', 1)\n        1\n        >>> sd.setdefault('a', 10)\n        1\n        >>> sd\n        SortedDict({'a': 1})\n\n        :param key: key for item\n        :param default: value for item (default None)\n        :return: value for item identified by `key`\n\n        ";C=default;B=key
		if B in A:return A[B]
		dict.__setitem__(A,B,C);A._list_add(B);return C
	def update(A,*B,**D):
		'Update sorted dict with items from `args` and `kwargs`.\n\n        Overwrites existing items.\n\n        Optional arguments `args` and `kwargs` may be a mapping, an iterable of\n        pairs or keyword arguments. See :func:`SortedDict.__init__` for\n        details.\n\n        :param args: mapping or iterable of pairs\n        :param kwargs: keyword arguments mapping\n\n        '
		if not A:dict.update(A,*(B),**D);A._list_update(dict.__iter__(A));return
		if not D and len(B)==1 and isinstance(B[0],dict):C=B[0]
		else:C=dict(*(B),**D)
		if 10*len(C)>len(A):dict.update(A,C);A._list_clear();A._list_update(dict.__iter__(A))
		else:
			for E in C:A._setitem(E,C[E])
	_update=update
	def __reduce__(A):'Support for pickle.\n\n        The tricks played with caching references in\n        :func:`SortedDict.__init__` confuse pickle so customize the reducer.\n\n        ';B=dict.copy(A);return type(A),(A._key,B)
	@recursive_repr()
	def __repr__(self):'Return string representation of sorted dict.\n\n        ``sd.__repr__()`` <==> ``repr(sd)``\n\n        :return: string representation\n\n        ';A=self;B=A._key;C=type(A).__name__;D=''if B is _A else '{0!r}, '.format(B);E='{0!r}: {1!r}'.format;F=', '.join((E(B,A[B])for B in A._list));return '{0}({1}{{{2}}})'.format(C,D,F)
	def _check(A):'Check invariants of sorted dict.\n\n        Runtime complexity: `O(n)`\n\n        ';B=A._list;B._check();assert len(A)==len(B);assert all((C in A for C in B))
def _view_delitem(self,index):
	"Remove item at `index` from sorted dict.\n\n    ``view.__delitem__(index)`` <==> ``del view[index]``\n\n    Supports slicing.\n\n    Runtime complexity: `O(log(n))` -- approximate.\n\n    >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n    >>> view = sd.keys()\n    >>> del view[0]\n    >>> sd\n    SortedDict({'b': 2, 'c': 3})\n    >>> del view[-1]\n    >>> sd\n    SortedDict({'b': 2})\n    >>> del view[:]\n    >>> sd\n    SortedDict({})\n\n    :param index: integer or slice for indexing\n    :raises IndexError: if index out of range\n\n    ";A=index;B=self._mapping;C=B._list;E=dict.__delitem__
	if isinstance(A,slice):
		F=C[A];del C[A]
		for D in F:E(B,D)
	else:D=C.pop(A);E(B,D)
class SortedKeysView(KeysView,Sequence):
	"Sorted keys view is a dynamic view of the sorted dict's keys.\n\n    When the sorted dict's keys change, the view reflects those changes.\n\n    The keys view implements the set and sequence abstract base classes.\n\n    ";__slots__=()
	@classmethod
	def _from_iterable(A,it):return SortedSet(it)
	def __getitem__(A,index):"Lookup key at `index` in sorted keys views.\n\n        ``skv.__getitem__(index)`` <==> ``skv[index]``\n\n        Supports slicing.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n        >>> skv = sd.keys()\n        >>> skv[0]\n        'a'\n        >>> skv[-1]\n        'c'\n        >>> skv[:]\n        ['a', 'b', 'c']\n        >>> skv[100]\n        Traceback (most recent call last):\n          ...\n        IndexError: list index out of range\n\n        :param index: integer or slice for indexing\n        :return: key or list of keys\n        :raises IndexError: if index out of range\n\n        ";return A._mapping._list[index]
	__delitem__=_view_delitem
class SortedItemsView(ItemsView,Sequence):
	"Sorted items view is a dynamic view of the sorted dict's items.\n\n    When the sorted dict's items change, the view reflects those changes.\n\n    The items view implements the set and sequence abstract base classes.\n\n    ";__slots__=()
	@classmethod
	def _from_iterable(A,it):return SortedSet(it)
	def __getitem__(E,index):
		"Lookup item at `index` in sorted items view.\n\n        ``siv.__getitem__(index)`` <==> ``siv[index]``\n\n        Supports slicing.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict({'a': 1, 'b': 2, 'c': 3})\n        >>> siv = sd.items()\n        >>> siv[0]\n        ('a', 1)\n        >>> siv[-1]\n        ('c', 3)\n        >>> siv[:]\n        [('a', 1), ('b', 2), ('c', 3)]\n        >>> siv[100]\n        Traceback (most recent call last):\n          ...\n        IndexError: list index out of range\n\n        :param index: integer or slice for indexing\n        :return: item or list of items\n        :raises IndexError: if index out of range\n\n        ";A=index;B=E._mapping;C=B._list
		if isinstance(A,slice):F=C[A];return[(A,B[A])for A in F]
		D=C[A];return D,B[D]
	__delitem__=_view_delitem
class SortedValuesView(ValuesView,Sequence):
	"Sorted values view is a dynamic view of the sorted dict's values.\n\n    When the sorted dict's values change, the view reflects those changes.\n\n    The values view implements the sequence abstract base class.\n\n    ";__slots__=()
	def __getitem__(D,index):
		"Lookup value at `index` in sorted values view.\n\n        ``siv.__getitem__(index)`` <==> ``siv[index]``\n\n        Supports slicing.\n\n        Runtime complexity: `O(log(n))` -- approximate.\n\n        >>> sd = SortedDict({'a': 2, 'b': 1, 'c': 3})\n        >>> svv = sd.values()\n        >>> svv[0]\n        2\n        >>> svv[-1]\n        3\n        >>> svv[:]\n        [2, 1, 3]\n        >>> svv[100]\n        Traceback (most recent call last):\n          ...\n        IndexError: list index out of range\n\n        :param index: integer or slice for indexing\n        :return: value or list of values\n        :raises IndexError: if index out of range\n\n        ";A=index;B=D._mapping;C=B._list
		if isinstance(A,slice):E=C[A];return[B[A]for A in E]
		F=C[A];return B[F]
	__delitem__=_view_delitem