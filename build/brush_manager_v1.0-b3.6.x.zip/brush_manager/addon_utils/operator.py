_C='SKIP_SAVE'
_B='HIDDEN'
_A=None
from typing import Any
import bpy
from bpy.types import Context,Event,OperatorProperties
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper
from ..types import AddonData,AddonDataByMode,UIProps
class OpsAction:
	ui_context_mode:StringProperty(default='',options={_B,_C});ui_context_item:StringProperty(default='',options={_B,_C})
	def _get_data(A,ui_props:UIProps,bm_data:AddonDataByMode,uuid:str|_A)->object:0
	def action(A,context:Context,ui_props:UIProps,bm_data:AddonDataByMode):0
	def execute(A,context:Context)->set[str]:
		D=context;C=UIProps.get_data(D)
		if D.area is not _A:A.tag_redraw=D.area.tag_redraw
		else:A.tag_redraw=lambda:_A
		if A.ui_context_mode!='':C.ui_context_mode=A.ui_context_mode.upper()
		if A.ui_context_item!='':C.ui_context_item=A.ui_context_item.upper()
		F=AddonData.get_data_by_context(C);B=_A
		if hasattr(A,'get_data'):
			E=A.get_data(C,F)
			if E is _A:return{'CANCELLED'}
			if not isinstance(E,tuple):B=A.action(E)
			else:B=A.action(*(E))
		else:B=A.action(D,C,F)
		A.tag_redraw()
		if B is not _A:
			if isinstance(B,set):return B
			if isinstance(B,str):return{B}
		return{'FINISHED'}
	@classmethod
	def draw_in_layout(A,layout,**B)->OperatorProperties:return layout.operator(A.bl_idname,**B)
	@classmethod
	def run(A,*B,**C)->_A:D,E=A.bl_idname.split('.');getattr(getattr(bpy.ops,D),E)(*(B),**C)
	@classmethod
	def __call__(A,*B,**C):A.run(B,**C)
class OpsInvokePropsPopup(OpsAction):
	bl_options={'REGISTER','UNDO'}
	def invoke(A,context:Context,event:Event):return context.window_manager.invoke_props_dialog(A,width=360)
class OpsImport(ImportHelper,OpsAction):0
class OpsImportBlend(OpsImport):filename_ext='.blend';filter_glob:StringProperty(default='*.blend',options={_B})
class OpsImportPNG(OpsImport):filename_ext='.png';filter_glob:StringProperty(default='*.png',options={_B})