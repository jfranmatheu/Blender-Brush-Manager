import re
from typing import Union
from bpy.types import Operator
from .operator import OpsAction,OpsInvokePropsPopup,OpsImportBlend,OpsImportPNG
class Reg:
	class Ops:
		ACTION=OpsAction;INVOKE_PROPS_POPUP=OpsInvokePropsPopup
		class Import:BLEND=OpsImportBlend;PNG=OpsImportPNG
		@staticmethod
		def setup(deco_cls)->Union[OpsAction,Operator]:A=deco_cls;B=re.findall('[A-Z][^A-Z]*',A.__name__);C:str='_'.join([A.lower()for A in B]);return type('BRUSHMANAGER_OT_'+C,(A,Operator),{'bl_idname':'brush_manager.'+C,'bl_label':A.label if hasattr(A,'label')else ' '.join(B)})