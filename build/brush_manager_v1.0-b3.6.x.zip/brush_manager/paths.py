_F='cat_textures'
_E='cat_brushes'
_D='textures'
_C='images'
_B='brushes'
_A=True
from enum import Enum
from pathlib import Path
from enum import Enum
from os.path import join,dirname,exists,isdir
from os import mkdir
import sys,bpy
b3d_user_path=bpy.utils.resource_path('USER')
b3d_config_path=join(b3d_user_path,'config')
b3d_appdata_path=dirname(bpy.utils.resource_path('USER'))
'\n* Linux *\nLOCAL: ./3.1/\nUSER: $HOME/.config/blender/3.1/\nSYSTEM: /usr/share/blender/3.1/\n-----\n* Mac OS *\nLOCAL: ./3.1/\nUSER: /Users/$USER/Library/Application Support/Blender/3.1/\nSYSTEM: /Library/Application Support/Blender/3.1/\n-----\n* Windows *\nLOCAL: .\x03.1USER: %USERPROFILE%\\AppData\\Roaming\\Blender Foundation\\Blender\x03.1SYSTEM: %USERPROFILE%\\AppData\\Roaming\\Blender Foundation\\Blender\x03.1'
def get_addondatadir()->Path:
	'\n    Returns a parent directory path\n    where persistent application data can be stored.\n\n    # linux: ~/.local/share\n    # macOS: ~/Library/Application Support\n    # windows: C:/Users/<USER>/AppData/Roaming\n    ';A=Path.home()
	if sys.platform=='win32':return A/'AppData/Roaming/Blender Foundation/Blender/addon_data'
	elif sys.platform=='linux':return A/'.local/share/blender/addon_data'
	elif sys.platform=='darwin':return A/'Library/Application Support/Blender/addon_data'
	'\n    import os\n\n    configpath = os.path.join(\n        os.environ.get(\'APPDATA\') or\n        os.environ.get(\'XDG_CONFIG_HOME\') or\n        os.path.join(os.environ[\'HOME\'], \'.config\'),\n        "Blender Foundation"\n    )\n    print(configpath)\n    '
class _Path_Enum(Enum):
	def __call__(A,*B,as_path:bool=False)->str|Path:
		C=as_path
		if not B:return A.value if C else str(A.value)
		return A.value.joinpath(*(B))if C else str(A.value.joinpath(*(B)))
src_path=Path(__file__).parent
user_data=Path(b3d_appdata_path)/'addon_data'/__package__
class Paths:
	ROOT=src_path;DATA=user_data;IMAGES=ROOT/_C;LIB=ROOT/'lib'
	class Lib(_Path_Enum):_LIB=src_path/'lib';DEFAULT_BLEND=_LIB/'default.blend'
	class Images(_Path_Enum):_IMAGES=src_path/_C;BRUSHES=_IMAGES/_B;ICONS=_IMAGES/'icons'
	class Scripts(_Path_Enum):_SCRIPTS=src_path/'scripts';EXPORT=_SCRIPTS/'export_brushes.py';EXPORT_JSON=_SCRIPTS/'export.json';WRITE_LIBS=_SCRIPTS/'write_libraries.py';CHECK__WRITE_LIBS=_SCRIPTS/'check_write_libraries.txt'
	class Data(_Path_Enum):_DATA=user_data;BRUSH=_DATA/_B;TEXTURE=_DATA/_D;CAT_BRUSH=_DATA/_E;CAT_TEXTURE=_DATA/_F
	class Icons(_Path_Enum):_ICONS=user_data/'icons';BRUSH=_ICONS/_B;TEXTURE=_ICONS/_D;CAT_BRUSH=_ICONS/_E;CAT_TEXTURE=_ICONS/_F
Paths.DATA.mkdir(parents=_A,exist_ok=_A)
Paths.Data.BRUSH.value.mkdir(exist_ok=_A)
Paths.Data.TEXTURE.value.mkdir(exist_ok=_A)
Paths.Data.CAT_BRUSH.value.mkdir(exist_ok=_A)
Paths.Data.CAT_TEXTURE.value.mkdir(exist_ok=_A)
Paths.Icons._ICONS.value.mkdir(exist_ok=_A)
Paths.Icons.BRUSH.value.mkdir(exist_ok=_A)
Paths.Icons.TEXTURE.value.mkdir(exist_ok=_A)
Paths.Icons.CAT_BRUSH.value.mkdir(exist_ok=_A)
Paths.Icons.CAT_TEXTURE.value.mkdir(exist_ok=_A)
'\nfor path_cls in _Path_Enum.__subclasses__():\n    for path_item in path_cls:\n        print(path_cls, path_item)\n        if hasattr(path_item, \'value\'):\n            print("\t>>> " + str(path_item.value))\n            dirpath: Path = path_item.value\n            if not dirpath.exists() and dirpath.is_dir():\n                dirpath.mkdir(parents=True)\n'