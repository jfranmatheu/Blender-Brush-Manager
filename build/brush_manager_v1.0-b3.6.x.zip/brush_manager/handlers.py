import bpy
from bpy.app import handlers
import atexit
first_time=True
@handlers.persistent
def initialize(*A):print('[brush_manager] load_post')
@handlers.persistent
def on_save_post(*B):print('[brush_manager] save_post');from .data import AddonData as A;A.save_all(save_items_id_data=True)
@atexit.register
def on_quit():
	A=False;global first_time
	if not first_time:return
	print('[brush_manager] atexit');first_time=A;from .data import AddonData as B;B.save_all(save_items_id_data=A)
def register():handlers.load_post.append(initialize);handlers.save_post.append(on_save_post)
def unregister():
	if on_save_post in handlers.save_post:handlers.save_post.remove(on_save_post)
	if initialize in handlers.load_post:handlers.load_post.remove(initialize)