_H='Expected int (index) or string (uuid)'
_G='dirty'
_F='.default.blend'
_E='.blend'
_D='Item_Collection'
_C=True
_B=False
_A=None
import bpy
from bpy.types import ID,Brush as BlBrush,Texture as BlTexture,ImageTexture as BlImageTexture,Context
from collections import OrderedDict
from shutil import copyfile
from typing import Iterator
from os.path import exists
from brush_manager.paths import Paths
from .common import IconHolder,IconPath
from brush_manager.utils.tool_settings import get_ts,get_ts_brush,get_ts_brush_texture_slot,set_ts_brush
from ..utils.callback import CallbackSetCollection
callback__ItemsAdd=CallbackSetCollection.init(_D,'items.add')
callback__ItemsRemove=CallbackSetCollection.init(_D,'items.remove')
callback__ItemsMovePre=CallbackSetCollection.init(_D,'items.move(pre)')
callback__ItemsMovePost=CallbackSetCollection.init(_D,'items.move(post)')
class Item(IconHolder):
	lib_path:Paths.Data;owner:object;fav:bool;select:bool;flags:set;type:str
	@property
	def id_data(self)->ID:return _A
	@property
	def collection(self)->'BrushItem_Collection':return self.owner
	@property
	def cat(self):' Wrapper prop for Item.owner (Category). ';from .cats import Category as A;B:A=self.collection.owner;return B
	@property
	def cat_id(self)->str:return self.cat.uuid
	def __init__(A,collection:'Item_Collection',name:str,**B)->_A:
		super().__init__(name);A.owner=collection;A.fav=_B;A.select=_B;A.flags=set()
		for (C,D) in B.items():setattr(A,C,D)
	def set_active(A,context:Context)->_A:0
	def load(A,link:bool=_B)->_A:raise NotImplementedError
	def save(A,compress:bool=_C)->_A:raise NotImplementedError
	def reset(A)->_A:raise NotImplementedError
	def remove(A)->_A:
		' You can remove directly from the item,\n            this will call the remove method from the parent. '
		if A.owner is not _A:A.collection.remove(A)
	def copy_data_from(A,item:'Item')->_A:raise NotImplemented
	def __del__(A)->_A:
		A.owner=_A;A.clear_icon();B=A.lib_path(A.uuid+_E,as_path=_C)
		if B.exists()and B.is_file():B.unlink()
class BrushItem(Item):
	lib_path=Paths.Data.BRUSH;icon_path=IconPath.BRUSH;use_custom_icon:bool;texture_uuid:str
	@property
	def id_data(self)->BlBrush:return bpy.data.brushes.get(self.uuid,_A)
	def set_active(B,context:Context)->_A:
		A=B.id_data
		if A is _A:A=B.load(link=_B,from_default=_B)
		set_ts_brush(context,A)
	def load(B,link:bool=_B,from_default:bool=_B)->BlBrush:
		A=B.id_data
		if A is not _A:bpy.data.brushes.remove(A);del A
		D=B.uuid+_F if from_default else B.uuid+_E;C=B.lib_path(D,as_path=_C)
		if not C.exists():print('WARN! Could not find Brush .blend lib-file at',str(C));return _A
		with bpy.data.libraries.load(str(C),link=link)as(E,F):F.brushes=E.brushes
		A=B.id_data
		if A is not _A:A['name']=B.name
		return A
	def save(A,compress:bool=_C,save_default:bool=_B)->_A:
		C=save_default;B=A.id_data
		if B is _A:return;raise RuntimeError(f"Can't save! No BlBrush was found with the uuid '{A.uuid}', in the blend data")
		if not C:
			if _G not in B:return
			del B[_G]
		D=A.uuid+_F if C else A.uuid+_E;E=A.lib_path(D,as_path=_B);bpy.data.libraries.write(E,{B},fake_user=_B,compress=compress)
	def save_default(A)->_A:A.save(compress=_C,save_default=_C)
	def reset(A)->_A:A.load(from_default=_C);copyfile(A.lib_path(A.uuid+_F,as_path=_B),A.lib_path(A.uuid+_E,as_path=_B))
	def copy_data_from(B,item:'BrushItem')->_A:
		A=item;B.type=A.type;B.texture_uuid=A.texture_uuid;B.use_custom_icon=A.use_custom_icon
		if A.use_custom_icon:
			C=A.icon_filepath
			if exists(C):D=B.icon_filepath;copyfile(C,D)
	def __del__(B)->_A:
		super().__del__();A=B.lib_path(B.uuid+_F,as_path=_C)
		if A.exists()and A.is_file():A.unlink()
class TextureItem(Item):
	lib_path=Paths.Data.TEXTURE;icon_path=IconPath.TEXTURE;format:str
	@property
	def id_data(self)->BlTexture:return bpy.data.textures.get(self.uuid,_A)
	def set_active(B,context:Context)->_A:
		A=B.id_data
		if A is _A:A=B.load(link=_C)
		get_ts_brush(context).texture_slot.texture=A
	def load(B,link:bool=_B)->_A:
		A=B.id_data
		if A is not _A:
			if isinstance(A,BlImageTexture)and A.image is not _A:bpy.data.images.remove(A.image)
			bpy.data.textures.remove(A);del A
		E=B.uuid+_E;F=B.lib_path(E,as_path=_B)
		with bpy.data.libraries.load(F,link=link)as(C,D):D.textures=C.textures;D.images=C.images
		A=B.id_data
		if A is not _A:A['name']=B.name
		return A
	def save(A,compress:bool=_C)->_A:
		B=A.id_data
		if B is _A:return;raise RuntimeError(f"Can't save! No BlTexture was found with the uuid '{A.uuid}', in the blend data")
		if _G not in B:return
		del B[_G];C=A.uuid+_E;D=A.lib_path(C,as_path=_B);bpy.data.libraries.write(D,{B},fake_user=_B,compress=compress)
	def copy_data_from(A,item:'TextureItem')->_A:A.type=item.type
class Item_Collection:
	active:Item;items:OrderedDict[str,Item];owner:object
	@property
	def count(self)->int:return len(self.items)
	@property
	def favs(self)->list[Item]:return[A for A in self if A.fav]
	@property
	def selected(self)->list[Item]:return[A for A in self if A.select]
	@property
	def active(self)->Item:return self.get(self._active)
	@property
	def active_id(self)->str:return self._active
	@active.setter
	def active(self,item:str|Item)->_A:
		A=item
		if A is _A:self._active='';return
		if not isinstance(A,(str,Item)):raise TypeError('Expected an Item instance or a string (uuid) but got:',type(A))
		self._active=A if isinstance(A,str)else A.uuid
	def __init__(A,cat:object)->_A:A.items=OrderedDict();A._active='';A.owner=cat
	def __iter__(A)->Iterator[Item]:return iter(A.items.values())
	def __getitem__(B,uuid_or_index:str|int)->Item|_A:
		A=uuid_or_index
		if isinstance(A,str):return B.items.get(A,_A)
		elif isinstance(A,int):
			C:int=A
			if C<0 or C>=len(B.items):return _A
			return list(B.items.values())[C]
		raise TypeError(_H)
	def get(A,uuid:str)->Item|_A:return A[uuid]
	def select(B,item:str)->_A:
		A=item
		if isinstance(A,Item):return B.select(A.uuid)
		if isinstance(A,int):C:int=A;return B.select(list(B.items.keys())[C])
		if isinstance(A,str)and A in B.items:B._active=A
	def add(B,name:str,_type=Item,**C)->Item:
		A=_type(B,name)
		for (D,E) in C.items():setattr(A,D,E)
		B.items[A.uuid]=A;callback__ItemsAdd(A);return A
	def move(C,item_uuid:str,other_coll:'Item_Collection')->_A:
		D=item_uuid;A=other_coll
		if not isinstance(A,Item_Collection):raise TypeError('Trying to move an item to another collection but the given type is not Item_Collection! but',type(A))
		callback__ItemsMovePre(C.items.get(D));B=C.remove(D,perma_remove=_B);A.items[B.uuid]=B;B.owner=A;callback__ItemsMovePost(B)
	def remove(B,uuid_or_index:int,perma_remove:bool=_C)->_A|Item:
		A=uuid_or_index
		if isinstance(A,str):
			if A in B.items:
				callback__ItemsRemove(B.items[A])
				if perma_remove:del B.items[A]
				else:return B.items.pop(A)
			return
		if isinstance(A,Item):return B.remove(A.uuid)
		if isinstance(A,int):C:int=A;return B.remove(list(B.items.keys())[C])
		raise TypeError(_H)
	def duplicate(B,item:Item|str)->Item|_A:
		A=item
		if not isinstance(A,(str,BrushItem,TextureItem)):raise TypeError('Trying to duplicate an Item that is not... an Item but:',type(A))
		A=B.get(A)if isinstance(A,str)else A;C=B.add(A.name+' Copy');C.copy_data_from(A)
	def clear(A)->_A:A.items.clear();A.active=_A
	def __del__(A)->_A:
		for B in reversed(A.items):del B
		A.owner=_A;A.clear()
	def clear_owners(A)->_A:
		A.owner=_A
		for B in A:B.owner=_A
	def ensure_owners(A,cat:object)->_A:
		A.owner=cat
		for B in A:B.owner=A
class BrushItem_Collection(Item_Collection):
	active:BrushItem;items:OrderedDict[str,BrushItem]
	def get(A,uuid:str)->BrushItem|_A:return super().get(uuid)
	def add(B,name:str='New Brush',**A)->BrushItem:return super().add(name,BrushItem,**A)
class TextureItem_Collection(Item_Collection):
	active:TextureItem;items:OrderedDict[str,TextureItem]
	def get(A,uuid:str)->TextureItem|_A:return super().get(uuid)
	def add(B,name:str='New Texture',**A)->TextureItem:return super().add(name,TextureItem,**A)