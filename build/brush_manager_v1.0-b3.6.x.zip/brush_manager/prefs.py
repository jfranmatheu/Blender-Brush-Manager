from bpy.types import AddonPreferences
from bpy.props import PointerProperty
from .data import AddonData
from .ops.op_toggle_prefs_ui import ToggleBrushManagerUI as OPS_TogglePrefsUI
class BrushManagerPreferences(AddonPreferences):
	bl_idname=__package__
	def draw(B,context):C=B.layout;A=C.row();A.scale_y=5.0;OPS_TogglePrefsUI.draw_in_layout(A,text='Manage')