from bpy.types import AddonPreferences
from bpy.props import PointerProperty
from.data import AddonData
from.ops.op_toggle_prefs_ui import ToggleBrushManagerUI as OPS_TogglePrefsUI
from.ops.op_data import ClearData
class BrushManagerPreferences(AddonPreferences):
	bl_idname=__package__
	def draw(C,context):D=C.layout;A=D.column();B=A.row();B.scale_y=5.;OPS_TogglePrefsUI.draw_in_layout(B,text='Manage');A.separator(factor=2);A.alert=True;ClearData.draw_in_layout(A,text='Clear BrushManager Data');A.alert=False