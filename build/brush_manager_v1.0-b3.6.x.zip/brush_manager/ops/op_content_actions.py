_F='TOGGLE'
_E='DESELECT_ALL'
_D='SELECT_ALL'
_C='SKIP_SAVE'
_B='HIDDEN'
_A=None
from bpy.types import Context,Event
from bpy.props import StringProperty,EnumProperty
from brush_manager.types import AddonData,UIProps,AddonDataByMode
from brush_manager.addon_utils import Reg
import brush_manager.types as bm_types
def get_category_items(self,context:Context):
	D='NONE';B=UIProps.get_data(context);C=AddonData.get_data_by_context(B);E=B.ui_context_item
	if E=='BRUSH':A=C.brush_cats
	else:A=C.texture_cats
	if A.count<=1:return[(D,D,'Please, create another Category!')]
	F=A.active_id;return[(B.uuid,B.name,B.name)for B in A if B.uuid!=F]
@Reg.Ops.setup
class SelectAll(Reg.Ops.ACTION):
	' Select-Action over Active Category items. ';select_action:EnumProperty(name='Select Action',items=((_F,'Toggle','Toggle Selected'),(_D,'Select All',''),(_E,'Deselect All','')),default=_D)
	def get_data(B,ui_props:UIProps,bm_data:AddonDataByMode)->bm_types.Category:A=bm_data;return A.brush_cats.active if ui_props.is_ctx_brush else A.texture_cats.active
	def action(B,cat:bm_types.Category)->_A:
		C=cat
		if B.select_action==_F:
			for A in C.items:A.select=not A.select
		elif B.select_action==_E:
			for A in C.items.selected:A.select=False
		elif B.select_action==_D:
			for A in C.items:A.select=True
@Reg.Ops.setup
class SelectItem(Reg.Ops.ACTION):
	' Select Item (toggle like). ';item_uuid:StringProperty(default='',options={_B,_C})
	def get_data(B,ui_props:UIProps,bm_data:AddonDataByMode)->bm_types.Category:A=bm_data;return A.brush_cats.active if ui_props.is_ctx_brush else A.texture_cats.active
	def action(B,cat:bm_types.Category):
		if cat is _A:return
		if(A:=cat.items.get(B.item_uuid)):A.select=not A.select
@Reg.Ops.setup
class RemoveSelectedFromActiveCategory(Reg.Ops.ACTION):
	' Removes all selected items from the active category. '
	def get_data(B,ui_props:UIProps,bm_data:AddonDataByMode)->bm_types.Category:A=bm_data;return A.brush_cats.active if ui_props.is_ctx_brush else A.texture_cats.active
	def action(B,cat:bm_types.Category)->_A:
		for A in cat.items.selected:cat.items.remove(A.uuid,perma_remove=True)
@Reg.Ops.setup
class MoveSelectedToCategory(Reg.Ops.INVOKE_PROPS_POPUP):
	' Move Selected items from the active category to the specified category. ';select_category:EnumProperty(name='Select a Category',items=get_category_items)
	def get_data(C,ui_props:UIProps,addon_data:AddonDataByMode)->bm_types.Category:
		A=addon_data
		if ui_props.is_ctx_brush:B=A.brush_cats.active;D=A.get_brush_cat(C.select_category)
		else:B=A.texture_cats.active;D=A.get_texture_cat(C.select_category)
		if B is _A:return _A
		return B,D
	def action(C,cat:bm_types.Category,target_cat:bm_types.Category)->_A:
		A=target_cat
		for B in cat.items.selected:cat.items.move(B.uuid,A.items)
		A.set_active();SelectAll.run(select_action=_E)
@Reg.Ops.setup
class AsignIconToBrush(Reg.Ops.Import.PNG):
	brush_uuid:StringProperty(default='',options={_B,_C})
	def get_data(A,_ui_props:UIProps,addon_data:AddonDataByMode)->bm_types.Category:B=addon_data;return B.active_category.items.get(A.brush_uuid)if A.brush_uuid!=''else B.active_brush
	def action(B,brush:bm_types.BrushItem|_A)->_A:
		A=brush
		if A is not _A:A.asign_icon(B.filepath)
@Reg.Ops.setup
class RenameItem(Reg.Ops.INVOKE_PROPS_POPUP):
	' Move Selected items from the active category to the specified category. ';item_uuid:StringProperty(default='',options={_B,_C});item_name:StringProperty(default='Name')
	def get_item(C,ui_props:UIProps,addon_data:AddonDataByMode)->bm_types.Category:
		A=addon_data
		if C.item_uuid=='':return A.active_item
		if ui_props.is_ctx_brush:B=A.brush_cats.active
		else:B=A.texture_cats.active
		if B is _A:return _A
		return B.items.get(C.item_uuid)
	def invoke(A,context:Context,event:Event):
		B=context;C=AddonData.get_data_by_context(B);D=UIProps.get_data(B);A.item=A.get_item(D,C)
		if A.item is _A:return{'CANCELLED'}
		A.item_name=A.item.name;return super().invoke(B,event)
	def action(A,*C)->_A:
		A.item.name=A.item_name
		if(B:=A.item.id_data):B['name']=A.item_name
@Reg.Ops.setup
class DuplicateBrush(Reg.Ops.ACTION):
	' Move Selected items from the active category to the specified category. ';brush_uuid:StringProperty(default='',options={_B,_C})
	def action(C,context:Context,ui_props:UIProps,bm_data:AddonDataByMode):
		A=bm_data.brush_cats.active;B=A.items.get(C.brush_uuid)
		if B is _A:return
		A.items.duplicate(B)