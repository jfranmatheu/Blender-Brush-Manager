_C='SKIP_SAVE'
_B='HIDDEN'
_A=None
from bpy.types import Event,Context
from bpy.props import StringProperty
from brush_manager.types import AddonDataByMode,UIProps,AddonData
from brush_manager.addon_utils import Reg
import brush_manager.types as bm_types
@Reg.Ops.setup
class NewCategory(Reg.Ops.INVOKE_PROPS_POPUP):
	cat_name:StringProperty(default='')
	def invoke(A,context:Context,event:Event):A.cat_name='Untitled Category';return super().invoke(context,event)
	def get_data(B,ui_props:UIProps,addon_data:AddonDataByMode)->bm_types.Category:A=addon_data;return A.new_brush_cat if ui_props.is_ctx_brush else A.new_texture_cat
	def action(A,new_category:callable)->_A:new_category(A.cat_name)
@Reg.Ops.setup
class RemoveCategory(Reg.Ops.ACTION):
	' Removes active category. '
	def action(C,context:Context,ui_props:UIProps,bm_data:AddonDataByMode)->_A:A=bm_data;B=A.brush_cats if ui_props.is_ctx_brush else A.texture_cats;B.remove(B.active_id)
@Reg.Ops.setup
class SelectCategory(Reg.Ops.ACTION):
	cat_uuid:StringProperty(default='')
	def action(B,context:Context,ui_props:UIProps,bm_data:AddonDataByMode)->_A:A=bm_data;C=A.brush_cats if ui_props.is_ctx_brush else A.texture_cats;C.select(B.cat_uuid)
@Reg.Ops.setup
class AsignIconToCategory(Reg.Ops.Import.PNG):
	cat_uuid:StringProperty(default='',options={_B,_C})
	def action(A,context:Context,ui_props:UIProps,bm_data:AddonDataByMode)->_A:
		D=ui_props;B=bm_data
		if A.cat_uuid!='':C=B.brush_cats.get(A.cat_uuid)if D.is_ctx_brush else B.texture_cats.get(A.cat_uuid)
		else:C=B.brush_cats.active if D.is_ctx_brush else B.texture_cats.active
		if C is not _A:C.asign_icon(A.filepath)
@Reg.Ops.setup
class RenameCategory(Reg.Ops.INVOKE_PROPS_POPUP):
	cat_uuid:StringProperty(default='',options={_B,_C});cat_name:StringProperty(default='Name')
	def get_cat(B,ui_props:UIProps,addon_data:AddonDataByMode)->bm_types.Category:
		C=addon_data
		if ui_props.is_ctx_brush:
			if B.cat_uuid=='':A=C.brush_cats.active
			else:A=C.get_brush_cat(B.cat_uuid)
		elif B.cat_uuid=='':A=C.texture_cats.active
		else:A=C.get_texture_cat(B.cat_uuid)
		if A is _A:return _A
		return A
	def invoke(A,context:Context,event:Event):
		B=context;C=AddonData.get_data_by_context(B);D=UIProps.get_data(B);A.cat=A.get_cat(D,C)
		if A.cat is _A:return{'CANCELLED'}
		A.cat_name=A.cat.name;return super().invoke(B,event)
	def action(A,*B)->_A:A.cat.name=A.cat_name