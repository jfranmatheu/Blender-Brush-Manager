from brush_manager.addon_utils import Reg
from brush_manager.paths import Paths
from shutil import rmtree
@Reg.Ops.setup
class ClearData(Reg.Ops.ACTION):
	def action(C,*D)->None:
		A=Paths.DATA
		if A.exists()and A.is_dir():rmtree(A)
		from brush_manager.data.addon_data import AddonData as B;B.clear_instances()