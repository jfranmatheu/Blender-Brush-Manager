_F='SKIP_SAVE'
_E='FINISHED'
_D='HIDDEN'
_C='RUNNING_MODAL'
_B=True
_A=None
import bpy
from bpy.types import Event,Context
from bpy.props import StringProperty,BoolProperty
from os.path import basename
from pathlib import Path
from time import time,sleep
import json,subprocess
from collections import deque
from typing import Type
from ..paths import Paths
from ..types import UIProps,AddonDataByMode,BrushItem,TextureItem,Item
from brush_manager.addon_utils import Reg
from brush_manager.globals import GLOBALS
@Reg.Ops.setup
class ImportLibrary(Reg.Ops.Import.BLEND):
	bl_idname='brushmanager.import_library';bl_label='Import a .blend Library';create_category:BoolProperty(default=_B,name='Setup Category',description='Create a category from',options={_D});custom_uuid:StringProperty(default='');exclude_defaults:BoolProperty(default=_B,options={_D,_F});use_modal:BoolProperty(default=_B,options={_D,_F})
	def action(A,context:Context,ui_props:UIProps,addon_data:AddonDataByMode)->_A:
		I=addon_data;H='CANCELLED';E=ui_props;D=context;print('[brush_manager] ImportLibrary:',A.filepath)
		if A.filepath=='':raise ValueError('filepath must not be empty');return{H}
		GLOBALS.is_importing_a_library=_B;B:Path=Paths.Scripts.EXPORT_JSON.value
		if B.exists():B.unlink(missing_ok=_B)
		print('Start Subprocess');A.process=subprocess.Popen([bpy.app.binary_path,A.filepath,'--background','--python',Paths.Scripts.EXPORT(),'-',E.ui_context_mode,str(int(A.exclude_defaults))],stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT,shell=False);J=time()+60
		while 1:
			if B.exists():break
			if time()>J:raise TimeoutError('ImportLibrary: Timeout expired for checking json existence')
		sleep(0.1);J=time()+60;C=_A
		while C is _A:
			with B.open('r')as P:
				K=P.read()
				if not K:print('\t> No raw data in export.json');sleep(0.1);return
				C:dict[str,dict]=json.loads(K)
			if time()>J:raise TimeoutError('ImportLibrary: Timeout expired for reading json')
		if C is _A:print('\t> Invalid data in export.json');A.end();return{H}
		B.unlink();A.brushes=deque(C['brushes']);A.textures=deque(C['textures']);A.brushes_count=F=len(A.brushes);A.textures_count=G=len(A.textures);print(f"export.json: brushes_count {F} - textures_count {G}")
		if F==0 and G==0:print('WARN: No data in export.json');A.end();return{H}
		L=_A;M=_A;E=UIProps.get_data(D);N=Path(A.filepath).stem.title()
		if G!=0:print('Create Texture Category');E.ui_context_item='TEXTURE';M=I.new_texture_cat(N,A.custom_uuid)
		if F!=0:print('Create Brush Category');E.ui_context_item='BRUSH';L=I.new_brush_cat(N,A.custom_uuid)
		Q=L.items.add if F!=0 else _A;R=M.items.add if G!=0 else _A;O:dict[str,object]={}
		def S(item_data:dict):A=item_data;B=O.get(A.pop('texture_uuid',''),_A);Q(texture=B,**A)
		def T(item_data:dict):A=item_data;O[A['uuid']]=R(**A)
		A.add_brush_to_data=S;A.add_texture_to_data=T;A.refresh_timer=time()+0.2;A.addon_data=I
		if A.use_modal:
			if not D.window_manager.modal_handler_add(A):print('ERROR: Window Manager was unable to add a modal handler');A.end();return{H}
			A._timer=D.window_manager.event_timer_add(1e-06,window=D.window);A.tag_redraw();return{_C}
		while 1:
			if _E in A.modal(_A,_A):break
		A.end();return{_E}
	def end(A):GLOBALS.is_importing_a_library=False
	def modal(A,context:Context,event:Event):
		C=event;B=context
		if C is not _A and C.type!='TIMER':return{'PASS_THROUGH'}
		if B is not _A:
			if time()>A.refresh_timer:A.refresh_timer=time()+0.2;A.tag_redraw()
		if A.textures_count!=0:A.textures_count-=1;A.add_texture_to_data(A.textures.popleft());return{_C}
		if A.brushes_count!=0:A.brushes_count-=1;A.add_brush_to_data(A.brushes.popleft());return{_C}
		if A.brushes_count==0 and A.textures_count==0:
			if B is not _A:B.window_manager.event_timer_remove(A._timer);del A._timer
			A.end();A.addon_data.save();return{_E}
		return{_C}