_D='path should be string, bytes, os.PathLike or integer, not '
_C='builtin'
_B='runtime'
_A=None
import bpy.utils.previews
from gpu.types import GPUTexture
from bpy.types import Image,ImagePreview
from bpy.utils import previews
from gpu import texture
from enum import Enum,auto
import numpy as np
from os.path import splitext,exists,isfile
import glob
from os.path import basename
from os import remove
from .paths import Paths
preview_collections:dict[str,previews.ImagePreviewCollection]={}
icon_gputex:dict[str,GPUTexture]={}
GPUTEX_ICON_SIZE=128,128
class Icons(Enum):
	BRUSH_PLACEHOLDER=auto();TEXTURE_PLACEHOLDER=auto()
	@property
	def icon_path(self)->str:return Paths.Images.ICONS(self.name.lower()+'.png')
	@property
	def icon_id(self)->int:return get_preview(self.name,self.icon_path,collection=_C)
	@property
	def gputex(self)->GPUTexture:return get_gputex(self.name,self.icon_path)
	def __call__(A)->int:return A.icon_id
	def draw(A,layout,text:str=''):layout.label(text=text,icon_value=A.icon_id)
def create_preview_from_filepath(uuid:str,input_filepath:str,output_filepath:str):
	C=input_filepath;A=output_filepath
	if not isinstance(C,str)or not isinstance(A,str):raise TypeError(_D,type(C),type(A))
	if exists(A):remove(A)
	B=bpy.data.images.load(C);B.scale(92,92);B.filepath_raw=A;B.save();bpy.data.images.remove(B);del B;new_preview(uuid,A,collection=_B,force_reload=True)
def new_preview(uuid:str,filepath:str,collection:str=_B,force_reload:bool=True)->_A:
	B=collection;A=uuid
	if(C:=preview_collections[B].get(A,_A)):del C;del preview_collections[B][A]
	return preview_collections[B].load(A,filepath,'IMAGE',force_reload=force_reload)
def get_preview(uuid:str,filepath:str,collection:str=_B)->int:
	D=collection;B=filepath;A=uuid
	if not exists(B)or not isfile(B):return 0
	E=preview_collections[D]
	if A not in E:new_preview(A,B,D)
	F:ImagePreview=E[A];return F.icon_id
	if(C:=preview_collections[_B].get(A,_A)):
		C:ImagePreview
		if C.icon_size[0]==0 or C.icon_size[1]==0:return 0
		return C.icon_id
	if B is not _A:return new_preview(A,B).icon_id
	return 0
def new_gputex(uuid:str,filepath:str)->GPUTexture:A:Image=bpy.data.images.load(filepath);B=texture.from_image(A);bpy.data.images.remove(A);del A;icon_gputex[uuid]=B;return B
def get_gputex(uuid:str,filepath:str,fallback:GPUTexture|_A=_A)->GPUTexture:
	A=filepath
	if(B:=icon_gputex.get(uuid,_A)):return B
	if not exists(A)or not isfile(A):return fallback
	return new_gputex(uuid,A)
def clear_icon(uuid:str,icon_filepath:str)->_A:
	B=uuid;A=icon_filepath
	if not isinstance(A,str):raise TypeError(_D,type(A))
	if not exists(A)or not isfile(A):return
	remove(A)
	if(D:=icon_gputex.get(B,_A)):del D;del icon_gputex[B]
	if(C:=preview_collections.get(_B,_A)):
		if(E:=C.get(B,_A)):del E;del C[B]
def register_icons():
	D='*.png'
	if preview_collections:bpy.utils.previews.remove(preview_collections[_C]);bpy.utils.previews.remove(preview_collections[_B]);preview_collections.clear()
	preview_collections[_C]=previews.new();preview_collections[_B]=previews.new();from .paths import Paths as C
	for A in glob.glob(C.Icons._ICONS('**',D)):B,E=splitext(basename(A));new_preview(B,A,collection=_B)
	for A in glob.glob(C.Images._IMAGES('**',D)):B,E=splitext(basename(A));new_preview(B.upper(),A,collection=_C)
def register():register_icons()
def unregister():bpy.utils.previews.remove(preview_collections[_C]);bpy.utils.previews.remove(preview_collections[_B]);preview_collections.clear()